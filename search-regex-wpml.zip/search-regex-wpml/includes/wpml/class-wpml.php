<?php
/* MTL: WPML */

namespace SearchRegex;

/**
 * Provides WPML availability and active language options
 */
class WPML {
	/** @var Bool */
	private $is_WPML_enabled = false;

	/** @var Array */
	private $languages = [];

	/**
	 * Create a WPML object with an active language option array
	 */
	public function __construct() {
		global $sitepress;

		/* if ( $sitepress instanceof SitePress ) */
		if ( is_object( $sitepress ) && get_class( $sitepress ) == 'SitePress' )
		{
			$this->is_WPML_enabled = true;
			$languages = $sitepress->order_languages( $sitepress->get_active_languages() );
			if ( ! empty( $languages ) ) {
				$this->languages[] = [ 'value' => '', 'label' => 'All' ];
				foreach ( $languages as $language ) {
					$this->languages[] = [ 'value' => $language['code'], 'label' => $language['display_name'] ];
				}
			}
		}
	}

	/**
	 * See if WMPL is enabled
	 *
	 * @return Bool WPML is enabled or not
	 */
	public function is_WPML_enabled() {
		return $this->is_WPML_enabled;
	}

	/**
	 * Get all the language options
	 *
	 * @return Array Array of language options
	 */
	public function get_languages() {
		return $this->languages;
	}

	/**
	 * Convert the language options to JSON
	 *
	 * @return array
	 */
	public function to_json() {
		return $this->languages;
	}
}
