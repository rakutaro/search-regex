<?php

namespace SearchRegex\Sql\Join;

use SearchRegex\Sql;

/**
 * Join on the post table
 * MTL: WPML
 */
class Translations extends Join {
	/**
	 * Join logic
	 *
	 * @var string
	 */
	private $logic;

	/**
	 * Source
	 *
	 * @var string
	 */
	private $source;

	/**
	 * Column to join
	 *
	 * @var string
	 */
	private $join_column;

	/**
	 * Constructor
	 *
	 * @param string $column Column.
	 * @param string $source Source.
	 */
	public function __construct( $column, $source ) {
		global $wpdb;

		$this->column = $column;
		$this->source = $wpdb->posts;
		$this->join_column = 'ID';
		$this->logic = '';
	}

	/**
	 * Set the logic for this join
	 *
	 * @param string $logic Logic.
	 * @return void
	 */
	public function set_logic( $logic ) {
		$this->logic = $logic;
	}

	public function get_select() {
		return new Sql\Select\Select( Sql\Value::table( $this->source ), Sql\Value::column( $this->join_column ), null, true );
	}

	public function get_from() {
		global $wpdb;

		$source = Sql\Value::table( $this->source );
		$column = Sql\Value::column( $this->join_column );

		return new Sql\From( Sql\Value::safe_raw( sprintf( "INNER JOIN {$wpdb->prefix}icl_translations ON {$wpdb->prefix}icl_translations.element_id=%s.%s", $source->get_value(), $column->get_value() ) ) );
	}

	public function get_join_column() {
		return $this->join_column;
	}

	public function get_join_value( $value ) {
		return "$value";
	}

	public function get_table() {
		return $this->source;
	}
}
