<?php

namespace SearchRegex\Source\Core;

use SearchRegex\Source;
use SearchRegex\Schema;
use SearchRegex\Search;	// MTL: WPML
use SearchRegex\Sql;

class Post_Meta extends Meta {
	/**
	 * The language query
	 * MTL: WPML
	 *
	 * @var Sql\Query
	 **/
	protected $language_query = null;

	/**
	 * Create a Source\Post object
	 * MTL: WPML
	 *
	 * @param Array                $handler Source handler information - an array of `name`, `class`, `label`, and `type`.
	 * @param array<Filter\Filter> $filters Array of Filter\Filter objects for this source.
	 * @param String               $language Language code to match
	 */
	public function __construct( array $handler, array $filters, $language = '' ) {
		global $wpdb, $searchregex_wpml;

		parent::__construct( $handler, $filters, $language );
		if ( $language !== '' && $searchregex_wpml->is_WPML_enabled() ) {
			$query = new Sql\Query();
			$query->add_select( new Sql\Select\Select( Sql\Value::table( $this->get_table_name() ), Sql\Value::column( $this->get_table_id() ) ) );
			$query->add_join( Sql\Join\Join::create( 'post', 'post-meta' ) );
			$query->add_join( Sql\Join\Join::create( 'translations', 'post' ) );
			$flags = new Search\Flags( [] );
			$query->add_where( new Sql\Where\Where_String( new Sql\Select\Select( Sql\Value::table( "{$wpdb->prefix}icl_translations" ), Sql\Value::column( 'element_type' ) ), 'begins', 'post_', $flags ) );
			$query->add_where( new Sql\Where\Where_String( new Sql\Select\Select( Sql\Value::table( "{$wpdb->prefix}icl_translations" ), Sql\Value::column( 'language_code' ) ), 'equals', $language, $flags ) );

//			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
//				// phpcs:ignore
//				error_log( 'SearchRegex language query: ' . var_export( $query, true ) );
//			}

			$this->language_query = $query;
		}
	}

	public function get_table_name() {
		global $wpdb;

		return $wpdb->postmeta;
	}

	public function get_meta_object_id() {
		return 'post_id';
	}

	public function get_meta_table() {
		return 'post';
	}

	public function get_meta_name() {
		return __( 'Post Meta', 'search-regex' );
	}

	public function autocomplete( array $column, $value ) {
		if ( $column['column'] === $this->get_meta_object_id() ) {
			return Source\Autocomplete::get_post( $value, Sql\Value::column( 'ID' ), Sql\Value::column( 'post_title' ) );
		}

		return parent::autocomplete( $column, $value );
	}

	public function convert_result_value( Schema\Column $schema, $value ) {
		if ( $schema->get_column() === 'post_id' ) {
			$post = get_post( intval( $value, 10 ) );

			if ( is_object( $post ) ) {
				return $post->post_title;
			}
		}

		return parent::convert_result_value( $schema, $value );
	}

	/**
	 * Get the language matching query  into a text label. For example, user ID to user name
	 * MTL: WPML
	 *
	 * @return null|Sql\Query Language matching query, or null
	 */
	public function get_language_query() {
		return $this->language_query;
	}
}
